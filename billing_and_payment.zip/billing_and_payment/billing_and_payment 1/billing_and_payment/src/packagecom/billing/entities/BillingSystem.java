package packagecom.billing.entities;

import java.sql.*;

public class BillingSystem {
    private Connection connection;

    public BillingSystem(Connection connection) {
        this.connection = connection;
    }

    
    public void generateInvoice(String patientId, double amount) {
        String checkPatientSQL = "SELECT * FROM patients WHERE patient_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(checkPatientSQL)) {
            pstmt.setString(1, patientId);
            ResultSet rs = pstmt.executeQuery();

            if (!rs.next()) {
                System.err.println("Error: Patient with ID " + patientId + " does not exist.");
                return; 
            }

            String insertInvoiceSQL = "INSERT INTO invoices (patient_id, amount, invoice_date, payment_status) VALUES (?, ?, NOW(), 'Unpaid')";
            try (PreparedStatement pstmtInvoice = connection.prepareStatement(insertInvoiceSQL, Statement.RETURN_GENERATED_KEYS)) {
                pstmtInvoice.setString(1, patientId);
                pstmtInvoice.setDouble(2, amount);
                int affectedRows = pstmtInvoice.executeUpdate();

                if (affectedRows == 0) {
                    throw new SQLException("Creating invoice failed, no rows affected.");
                }

               
                try (ResultSet generatedKeys = pstmtInvoice.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        String generatedInvoiceId = generatedKeys.getString(1);
                        System.out.println("Invoice created successfully with ID: " + generatedInvoiceId);
                    } else {
                        throw new SQLException("Invoice creation failed, no ID obtained.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   
    public void makePayment(String invoiceId, double amountPaid) {
        String checkInvoiceSQL = "SELECT * FROM invoices WHERE invoice_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(checkInvoiceSQL)) {
            pstmt.setString(1, invoiceId);
            ResultSet rs = pstmt.executeQuery();

            if (!rs.next()) {
                System.out.println("Error: Invoice with ID " + invoiceId + " does not exist.");
                return;
            }

            double amountDue = rs.getDouble("amount");
            if (amountPaid < amountDue) {
                System.out.println("Error: Payment amount is less than the invoice amount.");
                return;
            }

            String updateInvoiceSQL = "UPDATE invoices SET payment_status = 'Paid' WHERE invoice_id = ?";
            try (PreparedStatement updateStmt = connection.prepareStatement(updateInvoiceSQL)) {
                updateStmt.setString(1, invoiceId);
                updateStmt.executeUpdate();
                System.out.println("Payment processed successfully for Invoice ID: " + invoiceId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    
    public void viewAllPatients() {
        String query = "SELECT * FROM patients";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                System.out.println("Patient ID: " + rs.getString("patient_id"));
                System.out.println("Patient Name: " + rs.getString("name"));
                System.out.println("Patient Address: " + rs.getString("address"));
                System.out.println("Patient Phone: " + rs.getString("phone"));
                System.out.println("-------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View Billing History
    public void viewBillingHistory(String patientId) {
        String query = "SELECT * FROM invoices WHERE patient_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, patientId);
            ResultSet rs = pstmt.executeQuery();

            if (!rs.next()) {
                System.out.println("No billing history found for Patient ID: " + patientId);
                return;
            }

            System.out.println("Billing History for Patient ID: " + patientId);
            do {
                String invoiceId = rs.getString("invoice_id");
                double amount = rs.getDouble("amount");
                String invoiceDate = rs.getString("invoice_date");
                String paymentStatus = rs.getString("payment_status");

                System.out.println("Invoice ID: " + invoiceId);
                System.out.println("Amount: " + amount);
                System.out.println("Invoice Date: " + invoiceDate);
                System.out.println("Payment Status: " + paymentStatus);
                System.out.println("-----------------------------");

            } while (rs.next());

        } catch (SQLException e) {
            System.err.println("Error retrieving billing history: " + e.getMessage());
        }
    }
}
