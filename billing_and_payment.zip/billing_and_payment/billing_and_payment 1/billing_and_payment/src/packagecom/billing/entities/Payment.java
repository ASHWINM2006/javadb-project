package packagecom.billing.entities;

public abstract class Payment {
    protected String paymentId;
    protected double amountPaid;
    protected Invoice invoice;

   
    public Payment(String paymentId, double amountPaid, Invoice invoice) {
        this.paymentId = paymentId;
        this.amountPaid = amountPaid;
        this.invoice = invoice;
    }

    
    public abstract void processPayment();

    
    public String getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(String paymentId) {
        this.paymentId = paymentId;
    }

    public double getAmountPaid() {
        return amountPaid;
    }

    public void setAmountPaid(double amountPaid) {
        this.amountPaid = amountPaid;
    }

    public Invoice getInvoice() {
        return invoice;
    }

    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
    }
}
