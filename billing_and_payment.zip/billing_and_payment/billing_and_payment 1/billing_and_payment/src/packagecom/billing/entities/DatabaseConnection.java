package packagecom.billing.entities;

import java.sql.*;

public class DatabaseConnection {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/billing";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "12345678";

    private Connection connection;

    public DatabaseConnection() {
        try {
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addPatient(Patient patient) {
        String sql = "INSERT INTO patients (patient_id, name, address, phone) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, patient.getPatientId());
            pstmt.setString(2, patient.getName());
            pstmt.setString(3, patient.getAddress());
            pstmt.setString(4, patient.getPhone());
            pstmt.executeUpdate();
            System.out.println("Patient added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void generateInvoice(Patient patient, double amount) {
        String invoiceId = "INV-" + System.currentTimeMillis();
        String sql = "INSERT INTO invoices (invoice_id, patient_id, amount, date, payment_status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, invoiceId);
            pstmt.setString(2, patient.getPatientId());
            pstmt.setDouble(3, amount);
            pstmt.setDate(4, new Date(System.currentTimeMillis()));
            pstmt.setString(5, "Unpaid");
            pstmt.executeUpdate();
            System.out.println("Invoice generated for patient: " + patient.getName());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void makePayment(String invoiceId, double amountPaid, String paymentType) {
        String paymentId = "PAY-" + System.currentTimeMillis();
        String paymentSql = "INSERT INTO payments (payment_id, invoice_id, amount_paid, payment_date, payment_type) VALUES (?, ?, ?, ?, ?)";
        String updateInvoiceSql = "UPDATE invoices SET payment_status = 'Paid' WHERE invoice_id = ?";

        try (PreparedStatement paymentPstmt = connection.prepareStatement(paymentSql);
             PreparedStatement updateInvoicePstmt = connection.prepareStatement(updateInvoiceSql)) {

            paymentPstmt.setString(1, paymentId);
            paymentPstmt.setString(2, invoiceId);
            paymentPstmt.setDouble(3, amountPaid);
            paymentPstmt.setDate(4, new Date(System.currentTimeMillis()));
            paymentPstmt.setString(5, paymentType);
            paymentPstmt.executeUpdate();

            updateInvoicePstmt.setString(1, invoiceId);
            updateInvoicePstmt.executeUpdate();

            System.out.println("Payment processed for invoice ID: " + invoiceId);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewBillingHistory(String patientId) {
        String sql = "SELECT * FROM invoices WHERE patient_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, patientId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                System.out.println("Invoice ID: " + rs.getString("invoice_id") +
                                   ", Amount: " + rs.getDouble("amount") +
                                   ", Date: " + rs.getDate("date") +
                                   ", Status: " + rs.getString("payment_status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
