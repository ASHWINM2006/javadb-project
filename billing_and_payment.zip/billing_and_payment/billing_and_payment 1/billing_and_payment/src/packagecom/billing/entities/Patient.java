package packagecom.billing.entities;

import java.sql.*;

public class Patient {
    private String patientId;
    private String name;
    private String address;
    private String phone;
    private Connection connection;

    public Patient(String patientId, String name, String address, String phone, Connection connection) {
        this.patientId = patientId;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.connection = connection;
    }

   
    public void addPatient() {
        String insertSQL = "INSERT INTO patients (patient_id, name, address, phone) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
            pstmt.setString(1, patientId);
            pstmt.setString(2, name);
            pstmt.setString(3, address);
            pstmt.setString(4, phone);
            pstmt.executeUpdate();
            System.out.println("Patient added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	public String getName() {
		
		return null;
	}

	public String getPatientId() {
		
		return null;
	}

	public String getAddress() {
		
		return null;
	}

	public String getPhone() {
		
		return null;
	}
}
