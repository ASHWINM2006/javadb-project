package packagecom.billing.entities;

public class Invoice {
    private String invoiceId;
    private String patientId;
    private double amount;
    private String invoiceDate;
    private String paymentStatus;

    
    public Invoice(String invoiceId, String patientId, double amount, String invoiceDate, String paymentStatus) {
        this.invoiceId = invoiceId;
        this.patientId = patientId;
        this.amount = amount;
        this.invoiceDate = invoiceDate;
        this.paymentStatus = paymentStatus;
    }

    
    public String getInvoiceId() {
        return invoiceId;
    }

    public void setInvoiceId(String invoiceId) {
        this.invoiceId = invoiceId;
    }

    public String getPatientId() {
        return patientId;
    }

    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(String invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    @Override
    public String toString() {
        return "Invoice{" +
                "invoiceId='" + invoiceId + '\'' +
                ", patientId='" + patientId + '\'' +
                ", amount=" + amount +
                ", invoiceDate='" + invoiceDate + '\'' +
                ", paymentStatus='" + paymentStatus + '\'' +
                '}';
    }
}
