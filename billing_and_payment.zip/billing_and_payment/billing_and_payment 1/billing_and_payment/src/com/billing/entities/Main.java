package com.billing.entities;

import java.sql.*;

import java.util.Scanner;

import packagecom.billing.entities.BillingSystem;
import packagecom.billing.entities.Patient;

public class Main {
    public static void main(String[] args) {
       
        String url = "jdbc:mysql://localhost:3306/billing";
        String username = "root";
        String password = "12345678";
        Connection connection = null;

        try {
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connected successfully.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database.");
            e.printStackTrace();
            return;
        }

        BillingSystem billingSystem = new BillingSystem(connection);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nBilling and Payment System");
            System.out.println("1. Add Patient");
            System.out.println("2. View All Patients");
            System.out.println("3. Generate Invoice");
            System.out.println("4. Make Payment");
            System.out.println("5. View Billing History");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                  
                    System.out.print("Enter Patient ID: ");
                    String patientId = scanner.nextLine();
                    System.out.print("Enter Patient Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Patient Address: ");
                    String address = scanner.nextLine();
                    System.out.print("Enter Patient Phone: ");
                    String phone = scanner.nextLine();

                    
                    Patient patient = new Patient(patientId, name, address, phone, connection);
                    patient.addPatient();
                    break;

                case 2:
                    
                    billingSystem.viewAllPatients();
                    break;

                case 3:
                    
                    System.out.print("Enter Patient ID: ");
                    patientId = scanner.nextLine();
                    System.out.print("Enter Invoice Amount: ");
                    double amount = scanner.nextDouble();
                    scanner.nextLine(); 
                    billingSystem.generateInvoice(patientId, amount);
                    break;

                case 4:
                   
                    System.out.print("Enter Invoice ID: ");
                    String invoiceId = scanner.nextLine();
                    System.out.print("Enter Payment Amount: ");
                    double amountPaid = scanner.nextDouble();
                    scanner.nextLine(); 
                    billingSystem.makePayment(invoiceId, amountPaid);
                    break;

                case 5:
                    
                    System.out.print("Enter Patient ID to view billing history: ");
                    patientId = scanner.nextLine();
                    billingSystem.viewBillingHistory(patientId);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    try {
                        if (connection != null) {
                            connection.close();  
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    scanner.close();
                    return;

                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}